const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Dummy ML logic, replace with Python integration
function klasifikasiJasmani({ lari, pushup, pullup, situp, shuttlerun }) {
    // Skor sederhana (dummy):
    let skor = lari/30 + pushup*2 + pullup*3 + situp*2 - shuttlerun;
    let kategori = 'E';
    if (skor >= 85) kategori = 'A';
    else if (skor >= 70) kategori = 'B';
    else if (skor >= 55) kategori = 'C';
    else if (skor >= 40) kategori = 'D';
    return { kategori, skor };
}

app.post('/api/klasifikasi', (req, res) => {
    const data = req.body;
    const hasil = klasifikasiJasmani(data);
    res.json(hasil);
});

const PORT = 5000;
app.listen(PORT, () => {
    console.log('JasmaniAI backend running on port', PORT);
});
